
export default function ReportsList(){
  return (
    <div>
      <h1 className="text-xl font-semibold">My Reports</h1>
      <div className="text-sm text-gray-500">(Wire to /reports with filters)</div>
    </div>
  )
}
