
export default function Support(){
  return (
    <div>
      <h1 className="text-xl font-semibold">Support</h1>
      <p className="text-sm text-gray-600">FAQ + Contact form (stub)</p>
    </div>
  )
}
