
export default function NotFound(){
  return <div className="p-12 text-center">Not found</div>
}
