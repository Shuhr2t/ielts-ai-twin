
export default function SpeakingPart2(){
  return <div>Speaking Part 2 (prep 60s, speak 2:00). [Wire timers + upload]</div>
}
