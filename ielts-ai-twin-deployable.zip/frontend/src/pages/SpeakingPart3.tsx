
export default function SpeakingPart3(){
  return <div>Speaking Part 3. [Wire recorder + upload]</div>
}
